"""
config.py — loyihaning barcha sozlamalari shu yerda saqlanadi.

.env faylidan BOT_TOKEN va boshqa ixtiyoriy sozlamalar o'qiladi.
"""

import os
from pathlib import Path

from dotenv import load_dotenv

# .env faylini o'qib, qiymatlarni muhit o'zgaruvchilariga yuklaymiz
load_dotenv()

# ---------------------------------------------------------------------------
# Asosiy sozlamalar
# ---------------------------------------------------------------------------

# Telegram bot tokeni (@BotFather dan olinadi)
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "").strip()

# Loyiha papkasi va vaqtinchalik yuklamalar papkasi
BASE_DIR: Path = Path(__file__).resolve().parent
DOWNLOAD_DIR: Path = BASE_DIR / "downloads"

# Telegram Bot API orqali yuborish mumkin bo'lgan maksimal fayl hajmi (MB).
# Oddiy Bot API uchun chegara 50 MB. Agar o'zingizning Local Bot API
# serveringiz bo'lsa, bu qiymatni oshirishingiz mumkin (masalan, 2000).
MAX_FILE_SIZE_MB: int = int(os.getenv("MAX_FILE_SIZE_MB", "50"))

# Juda uzun videolarni yuklab olmaslik uchun maksimal davomiylik (soniyada).
# Standart: 30 daqiqa.
MAX_DURATION_SECONDS: int = int(os.getenv("MAX_DURATION_SECONDS", "1800"))

# Bir vaqtning o'zida nechta yuklab olish jarayoni ishlashi mumkin
# (server resurslarini himoya qilish uchun).
MAX_CONCURRENT_DOWNLOADS: int = int(os.getenv("MAX_CONCURRENT_DOWNLOADS", "3"))

# Ixtiyoriy: Instagram kabi tarmoqlar ba'zan cookies talab qiladi.
# Netscape formatidagi cookies.txt fayl yo'lini .env da ko'rsating.
COOKIES_FILE: str | None = os.getenv("COOKIES_FILE", "").strip() or None

# ---------------------------------------------------------------------------
# Foydalanuvchiga ko'rsatiladigan matnlar
# ---------------------------------------------------------------------------

START_TEXT: str = (
    "👋 <b>Xush kelibsiz!</b>\n\n"
    "Men ijtimoiy tarmoqlardan video va musiqalarni "
    "<b>suv belgisiz (watermark'siz)</b> yuklab beraman.\n\n"
    "📌 <b>Qo'llab-quvvatlanadigan tarmoqlar:</b>\n"
    "• 📸 Instagram — Reels, Post\n"
    "• ▶️ YouTube — Shorts, Video\n"
    "• 🎵 TikTok\n"
    "• 📍 Pinterest\n\n"
    "🔗 Shunchaki video havolasini (linkini) menga yuboring — "
    "qolganini o'zim bajaraman.\n"
    "🎧 Video ostidagi tugma orqali uning musiqasini ham ajratib olishingiz mumkin."
)

DOWNLOADING_TEXT: str = "⏳ Video yuklab olinmoqda, iltimos kuting..."
AUDIO_DOWNLOADING_TEXT: str = "⏳ Musiqa ajratib olinmoqda, iltimos kuting..."

ERROR_TEXT: str = (
    "Kechirasiz, bu havoladan video yuklab bo'lmadi. "
    "Havolani tekshirib qaytadan urinib ko'ring."
)

TOO_LARGE_TEXT: str = (
    "Kechirasiz, bu fayl hajmi juda katta, uni Telegram orqali yuborib bo'lmaydi "
    f"(maksimal {MAX_FILE_SIZE_MB} MB)."
)

NOT_A_LINK_TEXT: str = (
    "🔗 Iltimos, video havolasini (linkini) yuboring.\n"
    "Masalan: Instagram, YouTube, TikTok yoki Pinterest havolasi."
)

UNSUPPORTED_LINK_TEXT: str = (
    "⚠️ Bu havola qo'llab-quvvatlanmaydi.\n"
    "Faqat Instagram, YouTube, TikTok va Pinterest havolalarini yuboring."
)

EXPIRED_LINK_TEXT: str = "Havola eskirgan. Iltimos, videoni qaytadan yuboring."

AUDIO_BUTTON_TEXT: str = "🎵 Musiqasini ajratib olish"
