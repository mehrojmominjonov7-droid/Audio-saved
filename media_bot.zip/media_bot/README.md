# 🤖 Telegram media yuklovchi bot

Instagram (Reels, Post), YouTube (Shorts, Video), TikTok va Pinterest havolalaridan
video va musiqani **suv belgisiz** yuklab beradigan Telegram bot.

**Texnologiyalar:** Python 3.10+, [aiogram 3.x](https://docs.aiogram.dev/), [yt-dlp](https://github.com/yt-dlp/yt-dlp)

## ✨ Imkoniyatlar

- Havola qaysi platformaga tegishli ekanini avtomatik aniqlaydi
- Videoni eng sifatli (Telegram'ga mos H.264/MP4) formatda yuboradi
- Video ostidagi tugma orqali musiqasini MP3 ko'rinishida ajratib beradi
- Holat xabarlari: "⏳ Video yuklab olinmoqda..." va xatoliklar uchun tushunarli javoblar
- Yuborilgan fayllar `downloads/` papkasidan avtomatik o'chiriladi
- Bir vaqtda yuklashlar soni cheklangan (server resurslarini himoya qiladi)

## 📁 Struktura

```
media_bot/
├── main.py            # ishga tushirish
├── handlers.py        # /start, havola, "Musiqa" tugmasi
├── downloader.py      # platforma aniqlash + yt-dlp + cleanup
├── config.py          # sozlamalar va matnlar
├── requirements.txt
└── .env.example
```

## 🚀 O'rnatish va ishga tushirish

1. Repozitoriyni yuklab oling:
   ```bash
   git clone https://github.com/<foydalanuvchi>/<repo>.git
   cd <repo>
   ```
2. Kutubxonalarni o'rnating:
   ```bash
   pip install -r requirements.txt
   ```
3. **ffmpeg** o'rnating (video+audio birlashtirish va MP3 uchun shart):
   ```bash
   sudo apt install ffmpeg      # Ubuntu/Debian
   brew install ffmpeg          # macOS
   ```
4. `.env.example` faylidan nusxa olib, `.env` yarating va tokeningizni yozing
   ([@BotFather](https://t.me/BotFather) dan olinadi):
   ```bash
   cp .env.example .env
   ```
5. Botni ishga tushiring:
   ```bash
   python main.py
   ```

## ⚙️ Sozlamalar (`.env`)

| O'zgaruvchi | Tavsif | Standart |
|---|---|---|
| `BOT_TOKEN` | Telegram bot tokeni (majburiy) | — |
| `MAX_FILE_SIZE_MB` | Yuboriladigan maksimal fayl hajmi | `50` |
| `MAX_DURATION_SECONDS` | Maksimal video davomiyligi | `1800` |
| `MAX_CONCURRENT_DOWNLOADS` | Bir vaqtdagi yuklashlar soni | `3` |
| `COOKIES_FILE` | Instagram uchun cookies fayli yo'li | — |

## ⚠️ Eslatmalar

- Telegram Bot API 50 MB dan katta fayl yuborishga ruxsat bermaydi.
- Instagram ba'zan cookies talab qiladi (`COOKIES_FILE`).
- Faqat video bor havolalar ishlaydi; rasmli postlarda xato xabari chiqadi.
- yt-dlp ishlamay qolsa: `pip install -U yt-dlp`
- Bot faqat shaxsiy foydalanish uchun. Kontent mualliflarining huquqlariga hurmat bilan yondashing.
