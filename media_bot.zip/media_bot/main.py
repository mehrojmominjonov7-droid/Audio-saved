"""
main.py — botni ishga tushiruvchi asosiy fayl.

Ishga tushirish:  python main.py
"""

import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from config import BOT_TOKEN
from downloader import cleanup_all_downloads
from handlers import router

logger = logging.getLogger(__name__)


async def main() -> None:
    # Token mavjudligini tekshiramiz
    if not BOT_TOKEN:
        logger.critical("BOT_TOKEN topilmadi! .env fayliga BOT_TOKEN=... qo'shing.")
        sys.exit(1)

    # Oldingi ishdan qolgan vaqtinchalik fayllarni tozalaymiz
    cleanup_all_downloads()

    # Bot obyekti (xabarlar standart holda HTML formatida yuboriladi)
    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )

    dp = Dispatcher()
    dp.include_router(router)

    try:
        me = await bot.get_me()
        logger.info("Bot ishga tushdi: @%s", me.username)

        # Bot o'chiq paytida to'planib qolgan eski xabarlarni o'tkazib yuboramiz
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)
    finally:
        # Bot to'xtaganda sessiyani yopamiz va fayllarni tozalaymiz
        await bot.session.close()
        cleanup_all_downloads()
        logger.info("Bot to'xtatildi.")


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot qo'lda to'xtatildi.")
