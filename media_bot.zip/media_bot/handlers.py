"""
handlers.py — Telegram xabarlari va tugmalarini qayta ishlovchi handlerlar.
"""

import asyncio
import html
import logging
import re
import uuid
from collections import OrderedDict
from typing import Optional

from aiogram import Bot, F, Router
from aiogram.enums import ChatAction
from aiogram.filters import CommandStart
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import (
    AUDIO_BUTTON_TEXT,
    AUDIO_DOWNLOADING_TEXT,
    DOWNLOADING_TEXT,
    ERROR_TEXT,
    EXPIRED_LINK_TEXT,
    MAX_CONCURRENT_DOWNLOADS,
    NOT_A_LINK_TEXT,
    START_TEXT,
    TOO_LARGE_TEXT,
    UNSUPPORTED_LINK_TEXT,
)
from downloader import (
    FileTooLargeError,
    cleanup_folder,
    detect_platform,
    download_audio,
    download_video,
    extract_url,
)

logger = logging.getLogger(__name__)

router = Router()

# Bir vaqtda ishlayotgan yuklashlar sonini cheklaymiz
DOWNLOAD_SEMAPHORE = asyncio.Semaphore(MAX_CONCURRENT_DOWNLOADS)

# Callback tugmasi ma'lumoti 64 baytdan oshmasligi kerak, shuning uchun uzun
# havolani tugmaga sig'dirib bo'lmaydi. Havolani xotirada qisqa kalit bilan saqlaymiz.
URL_CACHE: "OrderedDict[str, str]" = OrderedDict()
URL_CACHE_LIMIT = 1000  # eng ko'pi bilan nechta havola saqlanadi


# ---------------------------------------------------------------------------
# Yordamchi funksiyalar
# ---------------------------------------------------------------------------


def remember_url(url: str) -> str:
    """Havolani keshga saqlab, qisqa kalit qaytaradi."""
    key = uuid.uuid4().hex[:12]
    URL_CACHE[key] = url
    # Kesh to'lib ketsa, eng eskilarini o'chiramiz
    while len(URL_CACHE) > URL_CACHE_LIMIT:
        URL_CACHE.popitem(last=False)
    return key


def audio_keyboard(url_key: str) -> InlineKeyboardMarkup:
    """Video ostidagi "Musiqasini ajratib olish" tugmasi."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=AUDIO_BUTTON_TEXT,
                    callback_data=f"audio:{url_key}",
                )
            ]
        ]
    )


async def safe_delete(message: Optional[Message]) -> None:
    """Xabarni o'chirishga urinadi; xatolik bo'lsa e'tiborsiz qoldiradi."""
    if not message:
        return
    try:
        await message.delete()
    except Exception as exc:  # noqa: BLE001
        logger.debug("Xabarni o'chirib bo'lmadi: %s", exc)


def safe_filename(name: str, default: str = "audio") -> str:
    """Fayl nomidan taqiqlangan belgilarni olib tashlaydi."""
    cleaned = re.sub(r'[\\/:*?"<>|\r\n]+', " ", name).strip()
    return cleaned[:60] or default


# ---------------------------------------------------------------------------
# /start buyrug'i
# ---------------------------------------------------------------------------


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    """Xush kelibsiz xabarini yuboradi."""
    try:
        await message.answer(START_TEXT)
    except Exception as exc:  # noqa: BLE001
        logger.exception("/start xatosi: %s", exc)


# ---------------------------------------------------------------------------
# Havola kelganda — videoni yuklab yuborish
# ---------------------------------------------------------------------------


@router.message(F.text)
async def handle_link(message: Message, bot: Bot) -> None:
    """Foydalanuvchi yuborgan havolani qabul qilib, videoni yuklab beradi."""
    url = extract_url(message.text or "")

    # 1) Xabarda havola bormi?
    if not url:
        await message.answer(NOT_A_LINK_TEXT)
        return

    # 2) Havola qo'llab-quvvatlanadigan tarmoqqa tegishlimi?
    platform = detect_platform(url)
    if not platform:
        await message.answer(UNSUPPORTED_LINK_TEXT)
        return

    logger.info("Yangi so'rov: user=%s platform=%s", message.from_user.id if message.from_user else "?", platform)

    # 3) Holat xabari
    status_msg: Optional[Message] = None
    result = None

    try:
        status_msg = await message.answer(DOWNLOADING_TEXT)
        await bot.send_chat_action(message.chat.id, ChatAction.UPLOAD_VIDEO)

        # 4) Yuklab olish (bir vaqtda cheklangan miqdorda)
        async with DOWNLOAD_SEMAPHORE:
            result = await download_video(url)

        # 5) Videoni yuborish
        await bot.send_chat_action(message.chat.id, ChatAction.UPLOAD_VIDEO)
        url_key = remember_url(url)
        caption = f"🎬 <b>{html.escape(result.title[:200])}</b>\n\n📥 Platforma: {platform}"

        await message.answer_video(
            video=FSInputFile(result.file_path),
            caption=caption,
            duration=result.duration,
            width=result.width,
            height=result.height,
            supports_streaming=True,
            reply_markup=audio_keyboard(url_key),
        )

        # 6) Holat xabarini o'chiramiz
        await safe_delete(status_msg)

    except FileTooLargeError:
        await safe_delete(status_msg)
        await message.answer(TOO_LARGE_TEXT)

    except Exception as exc:  # noqa: BLE001
        # Yaroqsiz havola, o'chirilgan video, tarmoq xatosi va h.k.
        logger.warning("Video yuklashda xatolik (%s): %s", url, exc)
        await safe_delete(status_msg)
        try:
            await message.answer(ERROR_TEXT)
        except Exception as send_exc:  # noqa: BLE001
            logger.error("Xato xabarini yuborib bo'lmadi: %s", send_exc)

    finally:
        # 7) Vaqtinchalik fayllarni har doim o'chiramiz (cleanup)
        if result:
            cleanup_folder(result.folder)


# ---------------------------------------------------------------------------
# "Musiqasini ajratib olish" tugmasi
# ---------------------------------------------------------------------------


@router.callback_query(F.data.startswith("audio:"))
async def handle_audio(callback: CallbackQuery, bot: Bot) -> None:
    """Videoning musiqasini MP3 ko'rinishida ajratib yuboradi."""
    message = callback.message
    if not isinstance(message, Message):
        await callback.answer()
        return

    url_key = (callback.data or "").split(":", 1)[1]
    url = URL_CACHE.get(url_key)

    if not url:
        await callback.answer(EXPIRED_LINK_TEXT, show_alert=True)
        return

    # Tugma "aylanib" qolmasligi uchun darhol javob beramiz
    await callback.answer("🎵 Musiqa ajratilmoqda...")

    status_msg: Optional[Message] = None
    result = None

    try:
        status_msg = await message.answer(AUDIO_DOWNLOADING_TEXT)
        await bot.send_chat_action(message.chat.id, ChatAction.UPLOAD_VOICE)

        async with DOWNLOAD_SEMAPHORE:
            result = await download_audio(url)

        await bot.send_chat_action(message.chat.id, ChatAction.UPLOAD_VOICE)
        await message.answer_audio(
            audio=FSInputFile(
                result.file_path,
                filename=f"{safe_filename(result.title)}.mp3",
            ),
            title=result.title[:64],
            performer=(result.uploader or "")[:64] or None,
            duration=result.duration,
            caption="🎧 Musiqa ajratib olindi",
        )

        await safe_delete(status_msg)

    except FileTooLargeError:
        await safe_delete(status_msg)
        await message.answer(TOO_LARGE_TEXT)

    except Exception as exc:  # noqa: BLE001
        logger.warning("Audio ajratishda xatolik (%s): %s", url, exc)
        await safe_delete(status_msg)
        try:
            await message.answer(ERROR_TEXT)
        except Exception as send_exc:  # noqa: BLE001
            logger.error("Xato xabarini yuborib bo'lmadi: %s", send_exc)

    finally:
        if result:
            cleanup_folder(result.folder)
