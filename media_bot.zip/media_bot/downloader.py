"""
downloader.py — havolani aniqlash va yt-dlp orqali video/audio yuklab olish.

Barcha og'ir (bloklovchi) ishlar alohida oqimda (thread) bajariladi,
shuning uchun bot boshqa foydalanuvchilarga javob berishda davom etadi.
"""

import asyncio
import logging
import re
import shutil
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

import yt_dlp
from yt_dlp.utils import match_filter_func

from config import (
    COOKIES_FILE,
    DOWNLOAD_DIR,
    MAX_DURATION_SECONDS,
    MAX_FILE_SIZE_MB,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Xatolik turlari
# ---------------------------------------------------------------------------


class DownloaderError(Exception):
    """Yuklab olishdagi umumiy xatolik."""


class FileTooLargeError(DownloaderError):
    """Fayl Telegram uchun juda katta."""


# ---------------------------------------------------------------------------
# Havolani aniqlash
# ---------------------------------------------------------------------------

# Matn ichidan havolani topish uchun regex
URL_REGEX = re.compile(r"https?://[^\s<>\"']+", re.IGNORECASE)

# Platforma nomi -> domen (host) regexi
PLATFORM_HOSTS: dict[str, re.Pattern] = {
    "Instagram": re.compile(r"(^|\.)(instagram\.com|instagr\.am)$"),
    "YouTube": re.compile(r"(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com)$"),
    "TikTok": re.compile(r"(^|\.)tiktok\.com$"),
    # Pinterest turli mamlakat domenlarida bo'ladi (pinterest.com, pinterest.co.uk ...)
    "Pinterest": re.compile(r"(^|\.)(pinterest\.[a-z.]{2,}|pin\.it)$"),
}


def extract_url(text: str) -> Optional[str]:
    """Matn ichidan birinchi havolani ajratib oladi."""
    match = URL_REGEX.search(text or "")
    if not match:
        return None
    # Havola oxiridagi ortiqcha belgilarni (nuqta, vergul, qavs) olib tashlaymiz
    return match.group(0).rstrip(".,;:!?)]}")


def detect_platform(url: str) -> Optional[str]:
    """Havola qaysi platformaga tegishli ekanini aniqlaydi."""
    try:
        host = (urlparse(url).hostname or "").lower()
    except ValueError:
        return None

    for platform, pattern in PLATFORM_HOSTS.items():
        if pattern.search(host):
            return platform
    return None


# ---------------------------------------------------------------------------
# Natija strukturasi
# ---------------------------------------------------------------------------


@dataclass
class DownloadResult:
    """Yuklab olingan faylning ma'lumotlari."""

    folder: Path  # shu yuklash uchun yaratilgan alohida papka
    file_path: Path  # yuklangan fayl yo'li
    title: str
    uploader: Optional[str]
    duration: Optional[int]
    width: Optional[int]
    height: Optional[int]


# ---------------------------------------------------------------------------
# Yordamchi funksiyalar
# ---------------------------------------------------------------------------


def cleanup_folder(folder: Optional[Path]) -> None:
    """Vaqtinchalik papkani butunlay o'chiradi (xatolik bo'lsa ham jim turadi)."""
    if not folder:
        return
    try:
        shutil.rmtree(folder, ignore_errors=True)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Papkani o'chirib bo'lmadi %s: %s", folder, exc)


def cleanup_all_downloads() -> None:
    """Bot ishga tushganda downloads/ papkasidagi eski qoldiqlarni tozalaydi."""
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    for item in DOWNLOAD_DIR.iterdir():
        try:
            if item.is_dir():
                shutil.rmtree(item, ignore_errors=True)
            else:
                item.unlink(missing_ok=True)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Eski faylni o'chirib bo'lmadi %s: %s", item, exc)


def _find_media_file(folder: Path) -> Optional[Path]:
    """Papkadagi eng katta tayyor media faylni topadi (.part va h.k. larni o'tkazib yuboradi)."""
    ignored_suffixes = {".part", ".ytdl", ".temp", ".json", ".jpg", ".jpeg", ".png", ".webp", ".vtt", ".srt"}
    candidates = [
        p for p in folder.iterdir()
        if p.is_file() and p.suffix.lower() not in ignored_suffixes
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_size)


def _common_options(folder: Path) -> dict:
    """Video va audio uchun umumiy yt-dlp sozlamalari."""
    opts: dict = {
        "outtmpl": str(folder / "media.%(ext)s"),
        "noplaylist": True,  # faqat bitta videoni yuklaymiz
        "quiet": True,
        "no_warnings": True,
        "retries": 3,
        "socket_timeout": 30,
        "restrictfilenames": True,
        # Juda uzun videolarni o'tkazib yuboramiz ("<=?" — davomiylik noma'lum bo'lsa ham o'tkazadi)
        "match_filter": match_filter_func(f"duration <=? {MAX_DURATION_SECONDS}"),
    }
    if COOKIES_FILE:
        opts["cookiefile"] = COOKIES_FILE
    return opts


def _video_options(folder: Path) -> dict:
    """Video yuklash sozlamalari: Telegram'ga mos H.264/MP4, hajm chegarasi ichida eng sifatli."""
    size = f"{MAX_FILE_SIZE_MB}M"
    opts = _common_options(folder)
    opts.update(
        {
            # Format tanlash (chapdan o'ngga, birinchi mos kelgani olinadi):
            # 1) H.264 video + M4A audio (hajm chegarasi ichida)
            # 2) tayyor MP4 (hajm chegarasi ichida)
            # 3) istalgan format (hajm chegarasi ichida)
            # 4) oxirgi chora — eng yaxshi mavjud format
            # TikTok'da yt-dlp standart holda suv belgisiz formatni tanlaydi.
            "format": (
                f"bv*[vcodec^=avc1][filesize<?{size}][filesize_approx<?{size}]+ba[ext=m4a]"
                f"/b[ext=mp4][filesize<?{size}][filesize_approx<?{size}]"
                f"/b[filesize<?{size}][filesize_approx<?{size}]"
                "/b"
            ),
            "merge_output_format": "mp4",  # ffmpeg kerak
        }
    )
    return opts


def _audio_options(folder: Path) -> dict:
    """Audio yuklash sozlamalari: eng yaxshi audio -> MP3 (ffmpeg kerak)."""
    opts = _common_options(folder)
    opts.update(
        {
            "format": "bestaudio/best",
            "postprocessors": [
                {
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "mp3",
                    "preferredquality": "192",
                }
            ],
        }
    )
    return opts


# ---------------------------------------------------------------------------
# Asosiy yuklash mantig'i (sinxron)
# ---------------------------------------------------------------------------


def _download_sync(url: str, audio_only: bool) -> DownloadResult:
    """yt-dlp yordamida faylni yuklab oladi. Alohida oqimda chaqiriladi."""
    # Har bir yuklash uchun noyob papka — fayllar aralashib ketmaydi
    folder = DOWNLOAD_DIR / uuid.uuid4().hex
    folder.mkdir(parents=True, exist_ok=True)

    try:
        options = _audio_options(folder) if audio_only else _video_options(folder)

        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=True)

        if not info:
            raise DownloaderError("Havoladan ma'lumot olinmadi.")

        # Agar natija bir nechta elementdan iborat bo'lsa (masalan, Instagram karusel),
        # birinchisini olamiz
        if "entries" in info:
            entries = [e for e in (info.get("entries") or []) if e]
            if not entries:
                raise DownloaderError("Havolada video topilmadi.")
            info = entries[0]

        file_path = _find_media_file(folder)
        if not file_path:
            # Fayl yuklanmagan: davomiylik yoki hajm chegarasidan oshgan bo'lishi mumkin
            raise DownloaderError("Fayl yuklanmadi (chegaradan oshgan yoki mavjud emas).")

        # Telegram chegarasini tekshiramiz
        size_mb = file_path.stat().st_size / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            raise FileTooLargeError(f"Fayl hajmi {size_mb:.1f} MB.")

        duration = info.get("duration")
        return DownloadResult(
            folder=folder,
            file_path=file_path,
            title=(info.get("title") or "Media").strip(),
            uploader=info.get("uploader") or info.get("channel"),
            duration=int(duration) if duration else None,
            width=info.get("width"),
            height=info.get("height"),
        )

    except Exception:
        # Xatolik bo'lsa — papkani darhol tozalab, xatoni yuqoriga uzatamiz
        cleanup_folder(folder)
        raise


# ---------------------------------------------------------------------------
# Asinxron interfeys (handlers.py shularni chaqiradi)
# ---------------------------------------------------------------------------


async def download_video(url: str) -> DownloadResult:
    """Videoni yuklab oladi (event loop'ni bloklamaydi)."""
    return await asyncio.to_thread(_download_sync, url, False)


async def download_audio(url: str) -> DownloadResult:
    """Videodan musiqani MP3 ko'rinishida ajratib oladi."""
    return await asyncio.to_thread(_download_sync, url, True)
